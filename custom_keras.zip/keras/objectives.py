"""Legacy objectives module.

Only kept for backwards API compatibility.
"""
from __future__ import absolute_import
from .losses import *
